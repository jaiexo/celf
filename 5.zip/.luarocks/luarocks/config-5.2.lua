rocks_trees = {
   { name = [[system]], root = [[/home/h/Self-Bot/.luarocks]] }
}
